# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '3b620c82a38a202d7a7e157d5bfde6d86a6e56f800cf3ef4413e533c9b442488b3d06ab3af5881556d85764cd59c137a02c09b4660caa726bbff0c5a64d28578'