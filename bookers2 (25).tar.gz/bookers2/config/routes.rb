Rails.application.routes.draw do
  devise_for :users
  root to: 'homes#top'
  get 'home/about', to: 'homes#about'
  resources :books, only: [:create, :index, :show, :update,:destroy,:edit] do
end  
  
  resources :users, only: [:show, :update, :edit, :index]
end